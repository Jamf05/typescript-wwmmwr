# typescript-wwmmwr

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/typescript-wwmmwr)
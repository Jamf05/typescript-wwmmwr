let nombre: string = 'Strider';
let hp: number | string = 95;
let vivo: boolean = true;

hp = 'FULL';

console.log(nombre, hp);
